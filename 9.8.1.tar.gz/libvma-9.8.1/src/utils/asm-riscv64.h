// asm-riscv64.h

#ifndef ASMRISCV64_H_
#define ASMRISCV64_H_

#include <stdint.h>
#include <unistd.h>

#define __xg(x) ((volatile long *)(x))


#define RISCV_FENCE(p, s) \
	__asm__ __volatile__ ("fence " #p "," #s : : : "memory")

/* These barriers need to enforce ordering on both devices or memory. */
#define mb()		RISCV_FENCE(iorw,iorw)
#define rmb()		RISCV_FENCE(ir,ir)
#define wmb()		RISCV_FENCE(ow,ow)
#define wc_wmb()	wmb()

#define __smp_store_release(p, v)					\
do {									\
	compiletime_assert_atomic_type(*p);				\
	RISCV_FENCE(rw,w);						\
	WRITE_ONCE(*p, v);						\
} while (0)

#define __smp_load_acquire(p)						\
({									\
	typeof(*p) ___p1 = READ_ONCE(*p);				\
	compiletime_assert_atomic_type(*p);				\
	RISCV_FENCE(r,rw);						\
	___p1;								\
})

#define COPY_64B_NT(dst, src)   \
    asm volatile(   \
    "ld  a0, %1\n"  \
    "ld  t0, 7*8(a0)\n" \
    "sd  t0, 7*8(%0)\n" \
    "ld  t0, 6*8(a0)\n" \
    "sd  t0, 6*8(%0)\n" \
    "ld  t0, 5*8(a0)\n" \
    "sd  t0, 5*8(%0)\n" \
    "ld  t0, 4*8(a0)\n" \
    "sd  t0, 4*8(%0)\n" \
    "ld  t0, 3*8(a0)\n" \
    "sd  t0, 3*8(%0)\n" \
    "ld  t0, 2*8(a0)\n" \
    "sd  t0, 2*8(%0)\n" \
    "ld  t0, 1*8(a0)\n" \
    "sd  t0, 1*8(%0)\n" \
    "ld  t0, 0*8(a0)\n" \
    "sd  t0, 0*8(%0)\n" \
    : : "r" (dst), "r" (src) : "memory"); \
    dst += 8; \
    src += 8

/**
 * Atomic swap
 */
static inline unsigned long xchg(unsigned long x, volatile void *ptr)
{
    unsigned long prev;
    asm volatile("amoswap.w %0, %1, %2" : "=r"(prev), "+A"(*(volatile long*)ptr) : "r"(x) : "memory");
    return prev;
}

/**
 * Atomic compare-and-swap
 */
static inline bool cmpxchg(unsigned long old_value, unsigned long new_value, volatile void *ptr)
{
    unsigned long prev;
    int success;
    asm volatile("amoswap.w %0, %1, %2\n\t"
                 "xor %0, %0, %3\n\t"
                 "snez %0, %0"
                 : "=&r"(success), "=&r" (prev), "+A"(*(volatile long*)ptr)
                 : "r" (old_value), "r" (new_value)
                 : "memory");
    return success;
}

/**
 * Add to the atomic variable.
 * @param i integer value to add.
 * @param v pointer of type atomic_t.
 * @return Value before add.
 */
static inline int atomic_fetch_and_add(int x, volatile int *ptr)
{
    int ret;
    asm volatile("amoadd.w %0, %2, %1" : "=r" (ret), "+A" (*ptr) : "r" ((int)x) : "memory");
    return ret;
}

/**
 * Read Cycle Counter
 */
static inline void gettimeoftsc(unsigned long long *p_tscval)
{
    uint64_t val;
    asm volatile("rdtime %0" : "=r" (val));
    *p_tscval = val;
}

/**
 * Cache Line Prefetch - Arch specific!
 */
#ifndef L1_CACHE_BYTES
#define L1_CACHE_BYTES		128
#endif

// static inline void prefetch(void *x)
// {
//     // 可能需要根据 RISC-V 架构的要求进行调整
//     asm volatile("fence\r\n.prfl 0(%0)" : : "r" (x) : "memory");
// }


#ifndef ARCH_HAS_PREFETCH
#define prefetch(x) __builtin_prefetch(x)
#endif
static inline void prefetch_range(void *addr, size_t len)
{
    char *cp = (char*)addr;
    char *end = (char*)addr + len;
    for (; cp < end; cp += L1_CACHE_BYTES)
        prefetch(cp);
}
#endif